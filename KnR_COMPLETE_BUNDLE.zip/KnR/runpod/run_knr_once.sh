#!/usr/bin/env bash
set -euo pipefail
cd /workspace/KnR/runpod
python3 /workspace/KnR/runpod/knr_gpu_direct_renderer.py --env /workspace/KnR/runpod/.env --once
