#!/usr/bin/env python3
"""
KnR RunPod trigger service - EASY EXACT AUTORUN.

Behavior implemented:
- Any /run request starts ONE controller thread, not duplicate renderers.
- The controller runs the renderer in all-rows mode until the sheet has no work.
- Renderer autopause is handled by restarting after KNR_AUTORESUME_DELAY_SECONDS.
- When no work is found twice in a row, the controller stops.
"""
import json
import os
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNNER_LOCK = threading.Lock()
RUNNER_THREAD = None
RUNNER_STARTED_AT = None
RUNNER_STOPPED_AT = None
RUNNER_STOP_REASON = ""
RUNNER_CYCLE = 0
RUNNER_EMPTY_CHECKS = 0
RUNNER_LAST_STATUS = {}
AUTOSTART_THREAD = None
AUTOSTART_STARTED_AT = None


def load_env(path: Path):
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def env_bool(name, default=False):
    raw = os.environ.get(name, str(default)).strip().lower()
    return raw in ("1", "true", "yes", "y", "on")


def env_int(name, default):
    try:
        return int(float(os.environ.get(name, str(default)).strip()))
    except Exception:
        return default


def status_file():
    return Path(os.environ.get("KNR_RENDER_STATUS_FILE", str(ROOT / "knr_renderer_last_status.json")))


def read_renderer_status():
    p = status_file()
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8", errors="ignore"))
        return data if isinstance(data, dict) else {}
    except Exception as e:
        return {"ok": False, "status_read_error": str(e)[:1000]}


def run_renderer_process(max_jobs=0):
    """Run one renderer pass. max_jobs=0 means process until no row or autopause."""
    env_path = os.environ.get("KNR_ENV_FILE", str(ROOT / ".env"))
    p = status_file()
    try:
        p.unlink()
    except FileNotFoundError:
        pass
    except Exception:
        pass

    cmd = [sys.executable, str(ROOT / "knr_gpu_direct_renderer.py"), "--env", env_path, "--max-jobs", str(int(max_jobs or 0))]
    log_path = ROOT / "knr_gpu_service_last_render.log"
    with log_path.open("a", encoding="utf-8") as log:
        log.write("\n\n==== Renderer pass start %s max_jobs=%s ====\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), max_jobs))
        log.write("Command: %s\n" % " ".join(cmd))
        log.flush()
        proc = subprocess.Popen(cmd, cwd=str(ROOT), stdout=log, stderr=subprocess.STDOUT)
        proc.wait()
        st = read_renderer_status()
        st.setdefault("exit_code", proc.returncode)
        log.write("Renderer status: %s\n" % json.dumps(st, sort_keys=True)[:4000])
        log.write("==== Renderer pass end exit=%s %s ====\n" % (proc.returncode, time.strftime("%Y-%m-%d %H:%M:%S")))
        log.flush()
        return st


def run_controller_loop(requested_limit=0):
    """Main easy run loop: autopause/autoresume until all rows are done, then stop after 2 empty checks."""
    global RUNNER_STOPPED_AT, RUNNER_STOP_REASON, RUNNER_CYCLE, RUNNER_EMPTY_CHECKS, RUNNER_LAST_STATUS

    max_empty_checks = max(1, env_int("KNR_AUTO_STOP_AFTER_EMPTY_CHECKS", 2))
    resume_delay = max(1, env_int("KNR_AUTORESUME_DELAY_SECONDS", 30))
    run_all = env_bool("KNR_RUN_ALL_AVAILABLE_ROWS", True)
    max_jobs = 0 if run_all else max(1, int(requested_limit or 1))

    RUNNER_STOPPED_AT = None
    RUNNER_STOP_REASON = ""
    RUNNER_CYCLE = 0
    RUNNER_EMPTY_CHECKS = 0
    RUNNER_LAST_STATUS = {}

    log_path = ROOT / "knr_gpu_service_last_render.log"
    with log_path.open("a", encoding="utf-8") as log:
        log.write("\n==== EASY AUTORUN CONTROLLER START %s ====\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
        log.write("Policy: run_all=%s, max_jobs=%s, autopause_before_timeout=%ss, autoresume_delay=%ss, stop_after_empty_checks=%s\n" % (
            run_all,
            max_jobs,
            env_int("KNR_AUTOPAUSE_BEFORE_TIMEOUT_SECONDS", 25),
            resume_delay,
            max_empty_checks,
        ))

    while True:
        RUNNER_CYCLE += 1
        st = run_renderer_process(max_jobs=max_jobs)
        RUNNER_LAST_STATUS = st

        exit_code = int(st.get("exit_code") or 0)
        if exit_code != 0:
            RUNNER_STOP_REASON = "renderer_error_exit_%s" % exit_code
            break

        jobs_done = int(st.get("jobs_done") or 0)
        autopaused = bool(st.get("autopaused"))
        no_job = bool(st.get("no_job"))

        if autopaused:
            RUNNER_EMPTY_CHECKS = 0
            with log_path.open("a", encoding="utf-8") as log:
                log.write("Controller: AUTOPAUSED. Sleeping %s seconds, then resuming same durable job from checkpoints.\n" % resume_delay)
            time.sleep(resume_delay)
            continue

        if no_job:
            RUNNER_EMPTY_CHECKS += 1
            with log_path.open("a", encoding="utf-8") as log:
                log.write("Controller: no available row check %s/%s.\n" % (RUNNER_EMPTY_CHECKS, max_empty_checks))
            if RUNNER_EMPTY_CHECKS >= max_empty_checks:
                RUNNER_STOP_REASON = "no_rows_left_after_%s_checks" % max_empty_checks
                break
            time.sleep(resume_delay)
            continue

        if jobs_done > 0:
            RUNNER_EMPTY_CHECKS = 0
            continue

        RUNNER_EMPTY_CHECKS += 1
        if RUNNER_EMPTY_CHECKS >= max_empty_checks:
            RUNNER_STOP_REASON = "no_progress_after_%s_checks" % max_empty_checks
            break
        time.sleep(resume_delay)

    RUNNER_STOPPED_AT = time.strftime("%Y-%m-%d %H:%M:%S")
    with log_path.open("a", encoding="utf-8") as log:
        log.write("==== EASY AUTORUN CONTROLLER STOP %s reason=%s cycles=%s empty_checks=%s ====\n" % (
            RUNNER_STOPPED_AT,
            RUNNER_STOP_REASON,
            RUNNER_CYCLE,
            RUNNER_EMPTY_CHECKS,
        ))


def start_runner(limit=0):
    global RUNNER_THREAD, RUNNER_STARTED_AT, RUNNER_STOPPED_AT, RUNNER_STOP_REASON
    with RUNNER_LOCK:
        if RUNNER_THREAD is not None and RUNNER_THREAD.is_alive():
            return False
        RUNNER_STARTED_AT = time.strftime("%Y-%m-%d %H:%M:%S")
        RUNNER_STOPPED_AT = None
        RUNNER_STOP_REASON = ""
        RUNNER_THREAD = threading.Thread(target=run_controller_loop, kwargs={"requested_limit": limit}, daemon=True)
        RUNNER_THREAD.start()
        return True


def runner_status():
    with RUNNER_LOCK:
        running = bool(RUNNER_THREAD is not None and RUNNER_THREAD.is_alive())
        return {
            "running": running,
            "started_at": RUNNER_STARTED_AT,
            "stopped_at": RUNNER_STOPPED_AT,
            "stop_reason": RUNNER_STOP_REASON,
            "cycle": RUNNER_CYCLE,
            "empty_checks": RUNNER_EMPTY_CHECKS,
            "last_renderer_status": RUNNER_LAST_STATUS,
        }


def autostart_once():
    global AUTOSTART_STARTED_AT
    AUTOSTART_STARTED_AT = time.strftime("%Y-%m-%d %H:%M:%S")
    initial_delay = max(0, env_int("KNR_AUTOSTART_INITIAL_DELAY_SECONDS", 5))
    time.sleep(initial_delay)
    if env_bool("KNR_AUTOSTART_ON_SERVICE_START", False):
        start_runner(0)


def start_autostart_thread():
    global AUTOSTART_THREAD
    if not env_bool("KNR_AUTOSTART_ON_SERVICE_START", False):
        return False
    if AUTOSTART_THREAD is not None and AUTOSTART_THREAD.is_alive():
        return True
    AUTOSTART_THREAD = threading.Thread(target=autostart_once, daemon=True)
    AUTOSTART_THREAD.start()
    return True


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, data):
        payload = json.dumps(data).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        st = runner_status()
        self._send(200, {
            "ok": True,
            "service": "KnR GPU trigger service",
            "status": "online",
            "renderer_running": st["running"],
            "renderer_started_at": st["started_at"],
            "renderer_stopped_at": st["stopped_at"],
            "renderer_stop_reason": st["stop_reason"],
            "controller_cycle": st["cycle"],
            "empty_checks": st["empty_checks"],
            "last_renderer_status": st["last_renderer_status"],
            "policy": {
                "run_all_available_rows": env_bool("KNR_RUN_ALL_AVAILABLE_ROWS", True),
                "autopause_before_timeout_seconds": env_int("KNR_AUTOPAUSE_BEFORE_TIMEOUT_SECONDS", 25),
                "autoresume_delay_seconds": env_int("KNR_AUTORESUME_DELAY_SECONDS", 30),
                "auto_stop_after_empty_checks": env_int("KNR_AUTO_STOP_AFTER_EMPTY_CHECKS", 2),
            }
        })

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length", "0") or 0)
            raw = self.rfile.read(n).decode("utf-8") if n else "{}"
            body = json.loads(raw or "{}")
            expected = os.environ.get("KNR_RENDER_SECRET", "").strip()
            remote_ip = (self.client_address[0] or "").strip()
            local_request = remote_ip in ("127.0.0.1", "::1")
            if expected and str(body.get("secret", "")) != expected and not local_request:
                self._send(401, {"ok": False, "error": "Unauthorized"})
                return

            action = str(body.get("action", "start_auto_run") or "start_auto_run").lower().strip()
            if action in ("health", "status"):
                st = runner_status()
                self._send(200, {"ok": True, "status": "online", "runner": st})
                return

            if action not in ("render_preview_once", "create_preview", "render_once", "run", "start", "autostart", "start_auto_run", "easy_autorun"):
                self._send(400, {"ok": False, "error": "Unknown action", "accepted_actions": ["start_auto_run", "render_preview_once", "status"]})
                return

            limit = int(body.get("limit") or body.get("max_jobs") or 0)
            started = start_runner(limit)
            st = runner_status()
            self._send(202, {
                "ok": True,
                "accepted": True,
                "started_new_controller": started,
                "already_running": not started,
                "message": "Easy autorun controller started: autopause/autoresume until all rows are done, then stop after two empty checks." if started else "Easy autorun controller is already running; no duplicate renderer started.",
                "renderer_running": st["running"],
                "renderer_started_at": st["started_at"],
                "policy": {
                    "run_all_available_rows": env_bool("KNR_RUN_ALL_AVAILABLE_ROWS", True),
                    "autopause_before_timeout_seconds": env_int("KNR_AUTOPAUSE_BEFORE_TIMEOUT_SECONDS", 25),
                    "autoresume_delay_seconds": env_int("KNR_AUTORESUME_DELAY_SECONDS", 30),
                    "auto_stop_after_empty_checks": env_int("KNR_AUTO_STOP_AFTER_EMPTY_CHECKS", 2),
                }
            })
        except Exception as e:
            self._send(500, {"ok": False, "error": str(e)[:2000]})


def main():
    load_env(Path(os.environ.get("KNR_ENV_FILE", str(ROOT / ".env"))))
    host = os.environ.get("KNR_GPU_SERVICE_HOST", "0.0.0.0")
    port = int(os.environ.get("KNR_GPU_SERVICE_PORT", "7860"))
    start_autostart_thread()
    srv = ThreadingHTTPServer((host, port), Handler)
    print(f"KnR GPU trigger service listening on http://{host}:{port}", flush=True)
    print(
        "Easy policy: run_all_available_rows=%s autopause_before_timeout=%ss autoresume_delay=%ss stop_after_empty_checks=%s" % (
            env_bool("KNR_RUN_ALL_AVAILABLE_ROWS", True),
            env_int("KNR_AUTOPAUSE_BEFORE_TIMEOUT_SECONDS", 25),
            env_int("KNR_AUTORESUME_DELAY_SECONDS", 30),
            env_int("KNR_AUTO_STOP_AFTER_EMPTY_CHECKS", 2),
        ),
        flush=True,
    )
    srv.serve_forever()


if __name__ == "__main__":
    main()
