#!/usr/bin/env bash
# ============================================================
# KnR RunPod Setup Script
# Run: bash /workspace/KnR/runpod/setup_knr.sh
# ============================================================
set -e
echo "============================================================"
echo "  KnR RunPod Setup Starting..."
echo "============================================================"
date

# ─── 1. Create directories ────────────────────────────────────
mkdir -p /workspace/KnR/runpod/backups
mkdir -p /workspace/KnR/models
mkdir -p /workspace/knr_runs
mkdir -p /workspace/KnR_BACKUPS
mkdir -p /root/.config/rclone

# ─── 2. Install apt packages ──────────────────────────────────
echo ""
echo "[1/7] Installing system packages..."
apt-get update -qq 2>/dev/null
for pkg in rclone espeak-ng ffmpeg unzip git; do
  dpkg -s "$pkg" >/dev/null 2>&1 || apt-get install -y -qq "$pkg" 2>/dev/null || true
done
echo "      Done."

# ─── 3. Install Python packages ───────────────────────────────
echo ""
echo "[2/7] Installing Python packages..."
python3 -m pip install -q -r /workspace/KnR/runpod/requirements.txt
echo "      Done."

# ─── 4. Restore rclone config ─────────────────────────────────
echo ""
echo "[3/7] Setting up rclone Google Drive access..."
if [ -f /workspace/KnR/runpod/backups/rclone.conf ]; then
  cp /workspace/KnR/runpod/backups/rclone.conf /root/.config/rclone/rclone.conf
  echo "      rclone.conf loaded from bundle."
elif [ -f /workspace/KnR/runpod/backups/rclone.conf.backup ]; then
  cp /workspace/KnR/runpod/backups/rclone.conf.backup /root/.config/rclone/rclone.conf
  echo "      rclone.conf loaded from backup."
else
  echo "      ERROR: No rclone.conf found."
  echo "      Run STEP1_GET_TOKEN.bat and STEP2_CREATE_CONF.bat on your PC"
  echo "      then re-upload the KnR folder."
  exit 1
fi

# Test rclone
echo "      Testing Drive access..."
if rclone lsf gdrive: --drive-root-folder-id 1WWjSb2gMpyL6lXxZsbNWPdEekqRgnhAj --max-depth 1 2>/dev/null; then
  echo "      [OK] Google Drive access confirmed."
else
  echo "      [WARN] rclone test failed."
  echo "      Run STEP1_GET_TOKEN.bat + STEP2_CREATE_CONF.bat on PC to fix."
  echo "      Continuing anyway (will fail at upload step if not fixed)."
fi

# ─── 5. Set up Wan2.1 repo ─────────────────────────────────────
echo ""
echo "[4/7] Setting up Wan2.1 video model repo..."
if [ -f /workspace/Wan2.1/generate.py ] && [ ! -f /workspace/KnR/models/Wan2.1/generate.py ]; then
  mkdir -p /workspace/KnR/models
  ln -sf /workspace/Wan2.1 /workspace/KnR/models/Wan2.1
  echo "      Symlinked from Docker image."
elif [ ! -f /workspace/KnR/models/Wan2.1/generate.py ]; then
  echo "      Cloning Wan2.1 (this may take 2 min)..."
  git clone --depth 1 https://github.com/Wan-Video/Wan2.1.git /workspace/KnR/models/Wan2.1
  echo "      Cloned."
else
  echo "      Already present."
fi

# Install Wan2.1 Python deps
if [ -f /workspace/KnR/models/Wan2.1/requirements.txt ]; then
  python3 -m pip install -q -r /workspace/KnR/models/Wan2.1/requirements.txt 2>/dev/null || true
fi

# ─── 6. Download Wan2.1 model ─────────────────────────────────
echo ""
echo "[5/7] Checking Wan2.1-T2V-1.3B model..."
WAN_MODEL=/workspace/KnR/models/Wan2.1-T2V-1.3B
if [ -d "$WAN_MODEL" ] && [ -n "$(find "$WAN_MODEL" -name '*.safetensors' 2>/dev/null | head -1)" ]; then
  echo "      Model already downloaded."
else
  echo "      Downloading model (~7 GB — this takes 10-15 minutes)..."
  export HF_TOKEN=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
  export HUGGING_FACE_HUB_TOKEN=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
  huggingface-cli download Wan-AI/Wan2.1-T2V-1.3B \
    --local-dir "$WAN_MODEL" \
    --token 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
  echo "      Model downloaded."
fi

# ─── 7. Backup rclone + bundle ────────────────────────────────
echo ""
echo "[6/7] Creating backup..."
if [ -f /root/.config/rclone/rclone.conf ]; then
  cp /root/.config/rclone/rclone.conf /workspace/KnR/runpod/backups/rclone.conf.backup
fi
DATE_TAG="$(date +%Y%m%d_%H%M%S)"
tar --exclude='KnR/models/Wan2.1-T2V-1.3B' \
    --exclude='KnR/models/Wan2.1/.git' \
    --exclude='KnR/**/__pycache__' \
    -czf "/workspace/KnR_BACKUPS/KnR_BUNDLE_${DATE_TAG}.tar.gz" \
    -C /workspace KnR 2>/dev/null \
  && echo "      Backup saved: /workspace/KnR_BACKUPS/KnR_BUNDLE_${DATE_TAG}.tar.gz" \
  || echo "      Backup skipped."

# ─── 8. Start GPU service ─────────────────────────────────────
echo ""
echo "[7/7] Starting KnR GPU service on port 7860..."
pkill -f knr_gpu_service.py 2>/dev/null || true
sleep 2
nohup bash /workspace/KnR/runpod/run_knr_gpu_service.sh \
  > /workspace/KnR/runpod/knr_gpu_service.log 2>&1 &
sleep 8

# ─── Health check ─────────────────────────────────────────────
if curl -sf http://127.0.0.1:7860/health > /dev/null 2>&1; then
  echo ""
  echo "============================================================"
  echo "  ALL DONE - KnR GPU service is RUNNING"
  echo "============================================================"
  echo ""
  echo "  NEXT: Get your RunPod public URL for port 7860"
  echo "  Go to: https://console.runpod.io/pods"
  echo "  Click your pod -> Connect -> copy the 7860 proxy URL"
  echo ""
  echo "  Then update ONE line in Apps Script:"
  echo "  https://docs.google.com/spreadsheets/d/1airVXLAKowwyB9J7K1tOxqEQf6aN3ztm2SpLXWgKDYY"
  echo "  -> Extensions -> Apps Script"
  echo "  -> Find:    GPU_RENDER_TRIGGER_URL: 'https://sk28044aqewu7r-7860.proxy.runpod.net/run',"
  echo "  -> Replace with: GPU_RENDER_TRIGGER_URL: 'https://YOURPODID-7860.proxy.runpod.net/run',"
  echo "  -> Press Ctrl+S"
  echo ""
  echo "  Then run KnR_startEasyAutoRun in Apps Script to start generating."
  echo "============================================================"
else
  echo ""
  echo "[ERROR] Service did not start. Check log:"
  echo "  tail -50 /workspace/KnR/runpod/knr_gpu_service.log"
fi
