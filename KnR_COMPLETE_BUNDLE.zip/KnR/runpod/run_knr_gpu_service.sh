#!/usr/bin/env bash
set -euo pipefail
cd /workspace/KnR/runpod
export KNR_ENV_FILE=/workspace/KnR/runpod/.env
python3 /workspace/KnR/runpod/knr_gpu_service.py
