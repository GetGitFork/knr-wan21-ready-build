#!/usr/bin/env python3
"""
KnR Kids Nursery Rhyme - RunPod Local GPU Wan Renderer

This renderer uses the rented RunPod GPU directly. It does not use the old
ByteDance ComfyUI node and does not use the local drawing fallback. It generates
scene clips with Wan2.1 T2V on the cloud GPU, stitches them, adds TTS/music-like
background audio, burns captions/watermark, uploads the MP4 to Google Drive, and
updates Apps Script.
"""

import argparse
import asyncio
import hashlib
import json
import math
import os
import random
import re
import shlex
import shutil
import subprocess
import sys
import time
import wave
from pathlib import Path

import requests

try:
    import edge_tts
except Exception:
    edge_tts = None

APP_NAME = "KnR Kids Nursery Rhyme - RunPod Local GPU Wan Renderer"
APP_VERSION = "4.2-exact-autopause-autoresume-all-rows"
PROVIDER_USED = "runpod_local_gpu_wan2_1_scene_renderer"
VIDEO_EXTS = {".mp4", ".webm", ".mov", ".mkv"}
ROOT = Path(__file__).resolve().parent


def load_env(path: Path):
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def env(name, default=""):
    return os.environ.get(name, default)


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)



RUN_STARTED_AT = time.time()


def env_bool(name, default=False):
    raw = os.environ.get(name, str(default)).strip().lower()
    return raw in ("1", "true", "yes", "y", "on")


def env_int(name, default):
    try:
        return int(float(os.environ.get(name, str(default)).strip()))
    except Exception:
        return default


def seconds_until_soft_stop():
    max_run = env_int("KNR_RENDER_MAX_RUN_SECONDS", 0)
    if max_run <= 0 or not env_bool("KNR_RENDER_AUTOPAUSE_ENABLED", True):
        return 999999999
    safety = max(5, env_int("KNR_AUTOPAUSE_BEFORE_TIMEOUT_SECONDS", 25))
    elapsed = time.time() - RUN_STARTED_AT
    return max(0, max_run - safety - elapsed)


def should_autopause_before_next_scene(min_seconds_needed=60):
    return seconds_until_soft_stop() <= max(10, int(min_seconds_needed))


def load_render_state(path: Path):
    if not path.exists():
        return {"completed_scenes": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {"completed_scenes": {}}
        data.setdefault("completed_scenes", {})
        return data
    except Exception:
        return {"completed_scenes": {}}


def save_render_state(path: Path, data: dict):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(path)


def autopause_job(row, job_id, lock, content_hash, state_path: Path, note):
    try:
        state = load_render_state(state_path)
        state["autopaused_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        state["autopause_note"] = note
        save_render_state(state_path, state)
    except Exception:
        pass
    log("AUTOPAUSE: " + note)
    post_app("pause", {
        "row": row,
        "job_id": job_id,
        "lock": lock,
        "content_hash": content_hash,
        "note": note,
    })




def write_renderer_status(data: dict):
    try:
        path = Path(env("KNR_RENDER_STATUS_FILE", str(ROOT / "knr_renderer_last_status.json")))
        payload = dict(data or {})
        payload.setdefault("written_at", time.strftime("%Y-%m-%d %H:%M:%S"))
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        tmp.replace(path)
    except Exception as e:
        try:
            log("Could not write renderer status file: " + str(e))
        except Exception:
            pass

def run(cmd, cwd=None, check=True, timeout=None, env_extra=None):
    merged_env = os.environ.copy()
    if env_extra:
        merged_env.update(env_extra)
    log("$ " + " ".join(str(x) for x in cmd))
    proc = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout, env=merged_env)
    if proc.stdout:
        print(proc.stdout[-6000:], flush=True)
    if check and proc.returncode != 0:
        raise RuntimeError(f"Command failed with exit code {proc.returncode}: {' '.join(map(str, cmd))}")
    return proc


def post_app(action, payload=None):
    url = env("KNR_APPS_SCRIPT_WEBAPP_URL").strip()
    secret = env("KNR_RENDER_SECRET").strip()
    if not url:
        raise RuntimeError("KNR_APPS_SCRIPT_WEBAPP_URL is missing in .env")
    if not secret:
        raise RuntimeError("KNR_RENDER_SECRET is missing in .env")
    body = {"secret": secret, "action": action}
    if payload:
        body.update(payload)
    r = requests.post(url, json=body, timeout=int(env("KNR_APPS_SCRIPT_TIMEOUT_SECONDS", "120")))
    if r.status_code >= 300:
        raise RuntimeError(f"Apps Script HTTP {r.status_code}: {r.text[:1500]}")
    data = r.json()
    if not data.get("ok"):
        raise RuntimeError(f"Apps Script error for {action}: {data}")
    return data


def check_command_available(name):
    if shutil.which(name) is None:
        raise RuntimeError(f"Required command missing on RunPod: {name}")


def safe_filename(name, max_len=145):
    name = re.sub(r"[\\/:*?\"<>|\r\n\t]+", " ", str(name or "")).strip()
    name = re.sub(r"\s+", " ", name)
    return name[:max_len].strip() or "KnR Kids Nursery Rhyme"


def slug_hash(text, n=10):
    return hashlib.sha1(str(text).encode("utf-8", errors="ignore")).hexdigest()[:n]


def parse_int(value, default):
    try:
        v = int(float(str(value).strip()))
        return v if v > 0 else default
    except Exception:
        return default


def parse_float(value, default):
    try:
        v = float(str(value).strip())
        return v if v > 0 else default
    except Exception:
        return default


def get_job(job, *keys, default=""):
    for k in keys:
        v = job.get(k)
        if v is not None and str(v).strip():
            return v
    return default


def choose_title(job, seed=0):
    idea = get_job(job, "output_title_idea", "Output Title Idea", "title", "Title", default="Kids Nursery Rhyme")
    idea = re.sub(r"#[A-Za-z0-9_]+", "", str(idea)).strip()
    return safe_filename(idea or "Kids Nursery Rhyme", 82)


def choose_hashtags(job):
    raw = get_job(job, "preferred_hashtags", "Preferred Hashtags", default="")
    prompt = " ".join([
        str(get_job(job, "storyline", "Storyline", default="")),
        str(get_job(job, "output_title_idea", "Output Title Idea", default="")),
        str(get_job(job, "master_video_prompt", "Master Video Prompt", default="")),
    ]).lower()
    tags = []
    def add(x):
        x = re.sub(r"[^A-Za-z0-9_]", "", str(x).replace("#", "")).strip()
        if x:
            h = "#" + x
            if h.lower() not in [t.lower() for t in tags]:
                tags.append(h)
    for item in re.split(r"[\s,;]+", env("KNR_REQUIRED_TITLE_HASHTAGS", "#kids #NurseryRhymes")):
        add(item)
    for item in re.findall(r"#[A-Za-z0-9_]+|[A-Za-z][A-Za-z0-9_]+", str(raw)):
        add(item)
    defaults = ["KidsSongs", "BabySongs", "ToddlerLearning", "PreschoolSongs", "LearningForKids", "CountingSong", "KidsMusic", "Shorts"]
    if re.search(r"abc|alphabet|phonics|letter", prompt):
        defaults.insert(0, "ABCSong")
    if re.search(r"color|colour|rainbow", prompt):
        defaults.insert(0, "ColorsForKids")
    for x in defaults:
        add(x)
    return tags[:20]


def choose_keywords(job):
    raw = get_job(job, "keyword_tags", "Keyword Tags", default="")
    idea = choose_title(job)
    defaults = [
        idea, "kids nursery rhymes", "nursery rhymes for kids", "kids songs", "baby songs",
        "toddler learning songs", "preschool songs", "educational kids video", "children songs",
        "counting song for kids", "learning video for toddlers", "kids music video", "original nursery rhyme"
    ]
    out = []
    for x in [s.strip() for s in re.split(r"[,;\n]+", str(raw)) if s.strip()] + defaults:
        x = re.sub(r"\s+", " ", str(x)).strip()
        # Remove old polluted WCF/ecommerce tags from kids project metadata.
        if re.search(r"war crimes|true crime|documentary|shopify|formal pants|esdeepee", x, re.I):
            continue
        if x and x.lower() not in [v.lower() for v in out]:
            out.append(x)
    return out[:20]


def fit_youtube_title(base, hashtags, max_len=100):
    base = safe_filename(re.sub(r"#[A-Za-z0-9_]+", "", str(base)), max_len).strip() or "Kids Nursery Rhyme"
    selected = []
    for h in list(hashtags or []):
        h = "#" + re.sub(r"[^A-Za-z0-9_]", "", str(h).replace("#", "")).strip()
        if h != "#" and h.lower() not in [x.lower() for x in selected]:
            trial = (base + " " + " ".join(selected + [h])).strip()
            if len(trial) <= max_len or not selected:
                selected.append(h)
        if len(selected) == 3:
            break
    suffix = " ".join(selected)
    if len((base + " " + suffix).strip()) > max_len:
        allowed = max(10, max_len - len(suffix) - 1)
        base = base[:allowed].rsplit(" ", 1)[0].strip() or base[:allowed].strip()
    return (base + " " + suffix).strip()


def extract_quoted_speech(prompt):
    lines = []
    for m in re.finditer(r"(?:Narrator(?: sings)?|Kids(?: repeat| sing)?|Song line)\s*:\s*\"([^\"]+)\"", prompt, flags=re.I):
        text = re.sub(r"\s+", " ", m.group(1)).strip()
        if text:
            lines.append(text)
    if not lines:
        for m in re.finditer(r"\"([^\"]{3,120})\"", prompt):
            text = m.group(1).strip()
            if text and not re.search(r"Counting Garden Helpers|CORE STYLE|FINAL QUALITY", text, re.I):
                lines.append(text)
    return lines


def auto_transcript(job):
    existing = get_job(job, "transcript", "Transcript", default="")
    if str(existing).strip():
        return str(existing).strip()
    prompt = str(get_job(job, "master_video_prompt", "Master Video Prompt", default=""))
    speech = extract_quoted_speech(prompt)
    if speech:
        return " ".join(speech)[:5000]
    story = str(get_job(job, "storyline", "Storyline", default=""))
    return re.sub(r"\s+", " ", story or prompt).strip()[:3500]


def default_time_marks(duration):
    labels = ["Opening", "Learning begins", "Main song", "Counting practice", "Final chorus", "Bye bye"]
    duration = max(30, int(duration))
    step = max(8, duration // len(labels))
    return "\n".join(f"{min(duration-1, i*step)//60}:{min(duration-1, i*step)%60:02d} - {label}" for i, label in enumerate(labels))


def parse_ts(s):
    m = re.match(r"(\d+):(\d{2})", s.strip())
    if not m:
        return 0
    return int(m.group(1)) * 60 + int(m.group(2))


def timed_scenes_from_prompt(prompt, total_duration):
    scenes = []
    pattern = re.compile(r"(?ms)^(\d+:\d{2})\s*-\s*(\d+:\d{2})\s+([^:\n]+):\s*(.*?)(?=^\d+:\d{2}\s*-\s*\d+:\d{2}\s+[^:\n]+:|\Z)")
    for m in pattern.finditer(prompt):
        start, end = parse_ts(m.group(1)), parse_ts(m.group(2))
        title = re.sub(r"\s+", " ", m.group(3)).strip()
        body = re.sub(r"\s+", " ", m.group(4)).strip()
        dur = max(3.0, float(end - start))
        if title and body:
            scenes.append({"title": title, "duration": dur, "body": body})
    if scenes:
        return scenes[:parse_int(env("KNR_WAN_MAX_SCENES", "12"), 12)]

    story = re.sub(r"\s+", " ", prompt).strip()
    chunks = ["Opening", "Scene 1", "Scene 2", "Scene 3", "Scene 4", "Finale"]
    per = max(4.0, float(total_duration) / len(chunks))
    return [{"title": c, "duration": per, "body": story[:900]} for c in chunks]


def build_scene_prompt(global_prompt, scene, scene_index, scene_count):
    body = scene["body"]
    title = scene["title"]
    clean_global = re.sub(r"\s+", " ", global_prompt).strip()
    if len(clean_global) > 1500:
        clean_global = clean_global[:1500]
    return (
        "Premium original preschool 3D animated nursery rhyme video, bright clean safe children's animation, "
        "rounded friendly characters, five diverse toddler-friendly children, glossy but not plastic, soft garden sunlight, "
        "gentle camera motion, cinematic colorful nursery rhyme style, no copied characters, no logos, no scary content. "
        f"Scene {scene_index+1} of {scene_count}: {title}. Scene action: {body}. "
        "Show the exact countable objects requested in this scene. Keep preschool pacing, happy expressions, soft motion, "
        "clear faces, consistent outfits, magical garden background, high quality 3D animated kids song look. "
        "Avoid text errors, distorted faces, extra fingers, mismatched counts, watermark, subtitles, or brand logos. "
        f"Overall video instruction context: {clean_global}"
    )[:3500]


def ensure_apps_script_requirements():
    data = post_app("preflight")
    log(f"Apps Script requirement check complete. checked={len(data.get('checked') or [])} missing={len(data.get('missing') or [])}")
    return data


def ensure_runpod_requirements():
    log("Checking RunPod local GPU Wan requirements before claiming a job.")
    for cmd in ["ffmpeg", "rclone", "python3"]:
        check_command_available(cmd)
    repo = Path(env("KNR_WAN_REPO_DIR", "/workspace/KnR/models/Wan2.1"))
    ckpt = Path(env("KNR_WAN_MODEL_DIR", "/workspace/KnR/models/Wan2.1-T2V-1.3B"))
    if not (repo / "generate.py").exists():
        raise RuntimeError(f"Wan repo is missing: {repo}. Run /workspace/KnR/runpod/install_runpod.sh first.")
    if not ckpt.exists() or not any(ckpt.iterdir()):
        raise RuntimeError(f"Wan model is missing or empty: {ckpt}. Run /workspace/KnR/runpod/install_runpod.sh first.")
    work_root = Path(env("KNR_WORK_DIR", "/workspace/knr_runs")); work_root.mkdir(parents=True, exist_ok=True)
    remote = env("KNR_RCLONE_REMOTE", "").strip().rstrip(":")
    if not remote:
        raise RuntimeError("KNR_RCLONE_REMOTE is missing. Configure rclone first.")
    folder_id = env("KNR_GDRIVE_FOLDER_ID", "").strip()
    if folder_id:
        probe = subprocess.run(["rclone", "lsf", f"{remote}:", "--drive-root-folder-id", folder_id], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if probe.returncode != 0:
            raise RuntimeError(f"Drive folder ID is not accessible through rclone: {folder_id}. Output: {probe.stdout[-1000:]}")
    log("RunPod requirements ready: GPU local Wan repo/model, ffmpeg, rclone, workdir, Drive folder.")


def find_newest_video(root: Path, since: float):
    found = []
    for p in root.rglob("*"):
        try:
            if p.is_file() and p.suffix.lower() in VIDEO_EXTS and p.stat().st_mtime >= since - 2:
                found.append(p)
        except Exception:
            pass
    if not found:
        return None
    return max(found, key=lambda p: p.stat().st_mtime)


def generate_wan_scene(prompt, seed, workdir: Path, scene_idx: int):
    repo = Path(env("KNR_WAN_REPO_DIR", "/workspace/KnR/models/Wan2.1"))
    ckpt = Path(env("KNR_WAN_MODEL_DIR", "/workspace/KnR/models/Wan2.1-T2V-1.3B"))
    task = env("KNR_WAN_TASK", "t2v-1.3B")
    size = env("KNR_WAN_SIZE", "832*480")
    timeout = int(env("KNR_WAN_TIMEOUT_SECONDS", "3600"))
    extra = shlex.split(env("KNR_WAN_EXTRA_ARGS", "--offload_model True --t5_cpu"))
    guide = env("KNR_WAN_GUIDE_SCALE", "6")
    shift = env("KNR_WAN_SHIFT", "8")
    scene_dir = workdir / f"wan_scene_{scene_idx:02d}"
    scene_dir.mkdir(parents=True, exist_ok=True)
    prompt_file = scene_dir / "prompt.txt"
    prompt_file.write_text(prompt, encoding="utf-8")
    before = time.time()
    cmd = [
        sys.executable, str(repo / "generate.py"),
        "--task", task,
        "--size", size,
        "--ckpt_dir", str(ckpt),
        "--sample_guide_scale", str(guide),
        "--sample_shift", str(shift),
        "--base_seed", str(seed),
        "--prompt", prompt,
    ] + extra
    run(cmd, cwd=scene_dir, timeout=timeout, env_extra={"PYTHONPATH": str(repo) + ":" + os.environ.get("PYTHONPATH", "")})
    newest = find_newest_video(scene_dir, before) or find_newest_video(repo, before) or find_newest_video(Path("/workspace"), before)
    if not newest:
        raise RuntimeError(f"Wan scene {scene_idx+1} finished but no video file was found.")
    out = scene_dir / f"scene_{scene_idx:02d}_wan_raw{newest.suffix.lower()}"
    if newest.resolve() != out.resolve():
        shutil.copy2(newest, out)
    return out


def make_scene_segment(raw_video: Path, out_path: Path, duration: float):
    width = int(env("KNR_FINAL_WIDTH", "1080")); height = int(env("KNR_FINAL_HEIGHT", "1920")); fps = int(env("KNR_FINAL_FPS", "24"))
    vf = f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},fps={fps},format=yuv420p"
    cmd = ["ffmpeg", "-y", "-stream_loop", "-1", "-i", str(raw_video), "-t", f"{duration:.3f}", "-vf", vf, "-an", "-c:v", "h264_nvenc", "-preset", env("KNR_NVENC_PRESET", "p4"), "-cq", env("KNR_NVENC_CQ", "18"), str(out_path)]
    proc = run(cmd, check=False)
    if proc.returncode != 0:
        cmd = ["ffmpeg", "-y", "-stream_loop", "-1", "-i", str(raw_video), "-t", f"{duration:.3f}", "-vf", vf, "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", str(out_path)]
        run(cmd)


def concat_segments(segments, out_path: Path):
    concat = out_path.parent / "concat_segments.txt"
    concat.write_text("\n".join("file '" + str(p).replace("'", "'\\''") + "'" for p in segments), encoding="utf-8")
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat), "-c", "copy", str(out_path)])


async def make_voice_async(text, out_path: Path):
    if edge_tts is None:
        raise RuntimeError("edge-tts is not installed")
    communicate = edge_tts.Communicate(
        text=text,
        voice=env("KNR_EDGE_TTS_VOICE", "en-US-AriaNeural"),
        rate=env("KNR_EDGE_TTS_RATE", "-4%"),
        pitch=env("KNR_EDGE_TTS_PITCH", "+8Hz"),
        volume=env("KNR_EDGE_TTS_VOLUME", "+0%"),
    )
    await communicate.save(str(out_path))


def make_voice(text, out_path: Path):
    try:
        asyncio.run(make_voice_async(text, out_path))
    except Exception as e:
        log("edge-tts failed; using espeak-ng fallback: " + str(e))
        wav = out_path.with_suffix(".wav")
        if shutil.which("espeak-ng") is None:
            raise
        run(["espeak-ng", "-v", "en-us+f3", "-s", "142", "-w", str(wav), text[:6000]])
        run(["ffmpeg", "-y", "-i", str(wav), "-filter:a", "atempo=1.02,asetrate=48000*1.05,aresample=48000", str(out_path)])


def make_background_audio(out_path: Path, duration: float, seed: int):
    rng = random.Random(seed)
    sr = 44100; total = int(duration * sr); samples = [0.0] * total
    palette = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99, 1046.50]
    bpm = rng.randint(88, 108); beat = 60.0 / bpm; t = 0.0
    while t < duration:
        freq = rng.choice(palette); start = int(t * sr); length = int(rng.uniform(0.10, 0.22) * sr); amp = rng.uniform(0.012, 0.032)
        for i in range(length):
            pos = start + i
            if pos >= total: break
            envv = math.exp(-4.8 * i / max(1, length))
            samples[pos] += amp * envv * math.sin(2 * math.pi * freq * i / sr)
        t += beat * rng.choice([0.5, 1.0, 1.5])
    # clap/giggle-like tiny percussion
    for i in range(0, total, max(1, int(sr * beat))):
        for j in range(int(sr * 0.025)):
            pos = i + j
            if pos < total:
                samples[pos] += rng.uniform(-0.005, 0.005) * math.exp(-9 * j / (sr * 0.025))
    with wave.open(str(out_path), "wb") as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr)
        frames = bytearray()
        for s in samples:
            s = max(-0.16, min(0.16, s))
            frames.extend(int(s * 32767).to_bytes(2, "little", signed=True))
        wf.writeframes(bytes(frames))


def make_srt(transcript, duration, out_path: Path):
    words = re.findall(r"\S+", transcript or "")
    if not words:
        words = ["Sing", "along", "and", "learn", "with", "me."]
    chunk_size = 7
    chunks = [" ".join(words[i:i+chunk_size]) for i in range(0, len(words), chunk_size)]
    max_chunks = max(1, min(len(chunks), int(max(8, duration // 2.8))))
    chunks = chunks[:max_chunks]
    step = duration / len(chunks)
    def ts(sec):
        ms = int((sec - int(sec)) * 1000); sec = int(sec)
        return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d},{ms:03d}"
    lines=[]
    for i,c in enumerate(chunks):
        lines += [str(i+1), f"{ts(i*step)} --> {ts(min(duration, (i+1)*step))}", c, ""]
    out_path.write_text("\n".join(lines), encoding="utf-8")


def ffmpeg_escape_drawtext_text(text):
    return str(text or "KnR").replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")


def build_watermark_filter():
    if env("KNR_WATERMARK_ENABLED", "true").lower() not in ("1", "true", "yes"):
        return ""
    text = ffmpeg_escape_drawtext_text(env("KNR_WATERMARK_TEXT", "KnR"))
    return f"drawtext=text='{text}':fontsize={env('KNR_WATERMARK_FONTSIZE','54')}:fontcolor=white@{env('KNR_WATERMARK_ALPHA','0.16')}:x='(w-text_w)/2+sin(t*0.65)*w*0.22':y='h*0.82+sin(t*0.45)*h*0.045':shadowcolor=black@0.20:shadowx=2:shadowy=2"


def normalize_to_final_mp4(input_video: Path, final_path: Path, workdir: Path, transcript: str, duration: float, seed: int):
    width = int(env("KNR_FINAL_WIDTH", "1080")); height = int(env("KNR_FINAL_HEIGHT", "1920")); fps = int(env("KNR_FINAL_FPS", "24"))
    video_filter = f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},fps={fps}"
    wm = build_watermark_filter()
    if wm: video_filter += "," + wm
    add_tts = env("KNR_ADD_TTS_AUDIO", "true").lower() in ("1", "true", "yes") and transcript.strip()
    add_caps = env("KNR_BURN_CAPTIONS", "true").lower() in ("1", "true", "yes") and transcript.strip()
    vf = video_filter + ",format=yuv420p"
    inputs = ["ffmpeg", "-y", "-i", str(input_video)]
    filter_complex = None
    maps = ["-map", "0:v"]
    if add_tts:
        voice = workdir / "knr_voice.mp3"; bg = workdir / "knr_music.wav"
        make_voice(transcript, voice); make_background_audio(bg, duration, seed)
        inputs += ["-i", str(voice), "-i", str(bg)]
        filter_complex = "[1:a]volume=1.0[a1];[2:a]volume=0.18[a2];[a1][a2]amix=inputs=2:duration=longest:dropout_transition=2[aout]"
        maps += ["-map", "[aout]"]
    if add_caps:
        srt = workdir / "captions.srt"; make_srt(transcript, duration, srt)
        vf += ",subtitles=captions.srt:force_style='FontName=Arial,FontSize=16,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=3,Outline=2,Shadow=1,Alignment=8,MarginV=120'"
    cmd = inputs + ["-vf", vf]
    if filter_complex:
        cmd += ["-filter_complex", filter_complex]
    cmd += maps + ["-t", f"{duration:.3f}", "-c:v", "h264_nvenc", "-preset", env("KNR_NVENC_PRESET", "p4"), "-cq", env("KNR_NVENC_CQ", "18"), "-c:a", "aac", "-b:a", "192k", "-shortest", str(final_path)]
    proc = run(cmd, cwd=workdir, check=False)
    if proc.returncode != 0:
        cmd = inputs + ["-vf", vf]
        if filter_complex:
            cmd += ["-filter_complex", filter_complex]
        cmd += maps + ["-t", f"{duration:.3f}", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "192k", "-shortest", str(final_path)]
        run(cmd, cwd=workdir)


def upload_rclone(final_path: Path, title: str):
    remote = env("KNR_RCLONE_REMOTE", "").strip().rstrip(":")
    folder = env("KNR_GDRIVE_FOLDER_NAME", "KnR videos").strip().strip("/")
    folder_id = env("KNR_GDRIVE_FOLDER_ID", "").strip()
    if not remote:
        raise RuntimeError("KNR_RCLONE_REMOTE is missing")
    filename = safe_filename(title, 118) + " - " + slug_hash(title + str(time.time())) + ".mp4"
    if folder_id:
        dest = f"{remote}:{filename}"
        cmd = ["rclone", "copyto", str(final_path), dest, "--drive-root-folder-id", folder_id, "--drive-chunk-size", env("KNR_RCLONE_CHUNK_SIZE", "128M"), "--progress"]
    else:
        dest = f"{remote}:{folder}/{filename}"
        cmd = ["rclone", "copyto", str(final_path), dest, "--drive-chunk-size", env("KNR_RCLONE_CHUNK_SIZE", "128M"), "--progress"]
    run(cmd)
    link_cmd = ["rclone", "link", dest]
    if folder_id: link_cmd += ["--drive-root-folder-id", folder_id]
    link_proc = run(link_cmd, check=False)
    url = (link_proc.stdout or "").strip().splitlines()[-1].strip() if link_proc.stdout else ""
    file_id = ""
    m = re.search(r"/d/([A-Za-z0-9_-]+)", url) or re.search(r"[?&]id=([A-Za-z0-9_-]+)", url)
    if m: file_id = m.group(1)
    return {"url": url, "file_id": file_id, "filename": filename, "remote_path": dest}


def build_description(title, transcript, time_marks, product_title, product_url, hashtags, keywords):
    parts = [title, "", transcript.strip()]
    if time_marks.strip(): parts += ["", time_marks.strip()]
    parts += ["", " ".join(hashtags[:20]), "", ", ".join(keywords[:20])]
    return "\n".join(parts).strip()[:4900]


def render_job(claim):
    job = claim["job"]; row = claim["row"]; lock = claim["lock"]; job_id = claim.get("job_id") or job.get("job_id") or ""
    seed = int(claim.get("render_seed") or get_job(job, "seed", "Seed", default=12345678))
    duration = parse_float(get_job(job, "duration_seconds", "Duration Seconds"), parse_float(env("KNR_DEFAULT_DURATION_SECONDS", "164"), 164.0))
    duration = min(max(10.0, duration), parse_float(env("KNR_MAX_DURATION_SECONDS", "180"), 180.0))
    content_hash = claim.get("content_hash") or slug_hash(json.dumps(job, sort_keys=True))
    work_root = Path(env("KNR_WORK_DIR", "/workspace/knr_runs")); workdir = work_root / f"row_{row}_{content_hash[:10]}"
    resume_enabled = env_bool("KNR_RESUME_WORKDIR", True)
    state_path = workdir / "render_state.json"
    if workdir.exists() and env("KNR_CLEAN_WORKDIR_BEFORE_RENDER", "true").lower() in ("1", "true", "yes") and not resume_enabled:
        shutil.rmtree(workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    state = load_render_state(state_path)
    prompt = str(get_job(job, "master_video_prompt", "Master Video Prompt", default=""))
    if not prompt.strip():
        raise RuntimeError("Master Video Prompt is empty.")
    transcript = auto_transcript(job)
    time_marks = get_job(job, "time_marks", "Time Marks", default=default_time_marks(duration))
    base_title = choose_title(job, seed); hashtags = choose_hashtags(job); keywords = choose_keywords(job); youtube_title = fit_youtube_title(base_title, hashtags)
    scenes = timed_scenes_from_prompt(prompt, duration)
    total_scene_dur = sum(float(s["duration"]) for s in scenes)
    if total_scene_dur <= 0: total_scene_dur = duration
    # Scale scene durations to requested final duration.
    for s in scenes:
        s["duration"] = max(3.0, float(s["duration"]) * duration / total_scene_dur)
    log(f"Rendering row {row} with local RunPod GPU Wan scene pipeline. scenes={len(scenes)} workdir={workdir}")
    post_app("heartbeat", {"row": row, "job_id": job_id, "lock": lock, "content_hash": content_hash, "note": f"Local GPU Wan scene renderer started. scenes={len(scenes)}"})
    segments = []
    completed_scenes = state.setdefault("completed_scenes", {})
    for i, scene in enumerate(scenes):
        seg = workdir / f"scene_{i:02d}_timed.mp4"
        scene_key = str(i)
        if completed_scenes.get(scene_key) and seg.exists() and seg.stat().st_size > 10000:
            log(f"Resume checkpoint: using completed scene {i+1}/{len(scenes)}: {seg}")
            segments.append(seg)
            continue
        if should_autopause_before_next_scene(max(60, int(float(scene.get("duration", 5)) * 2))):
            note = f"Autopaused before scene {i+1}/{len(scenes)} with {int(seconds_until_soft_stop())} seconds left before soft timeout. Auto-resume will continue from the last completed scene checkpoint."
            autopause_job(row, job_id, lock, content_hash, state_path, note)
            return "AUTOPAUSED"
        sprompt = build_scene_prompt(prompt, scene, i, len(scenes))
        post_app("heartbeat", {"row": row, "job_id": job_id, "lock": lock, "content_hash": content_hash, "note": f"Generating AI scene {i+1}/{len(scenes)}: {scene['title']}"})
        raw = generate_wan_scene(sprompt, seed + i * 101, workdir, i)
        make_scene_segment(raw, seg, float(scene["duration"]))
        completed_scenes[scene_key] = {"segment": str(seg), "completed_at": time.strftime("%Y-%m-%d %H:%M:%S"), "title": scene.get("title", "")}
        save_render_state(state_path, state)
        segments.append(seg)
    joined = workdir / "joined_ai_scenes.mp4"
    concat_segments(segments, joined)
    final_path = workdir / (safe_filename(youtube_title, 108) + ".mp4")
    post_app("heartbeat", {"row": row, "job_id": job_id, "lock": lock, "content_hash": content_hash, "note": "Adding nursery voice, music bed, captions, watermark, and final MP4 encoding."})
    normalize_to_final_mp4(joined, final_path, workdir, transcript, duration, seed)
    if not final_path.exists() or final_path.stat().st_size < 100000:
        raise RuntimeError("Final MP4 was not created correctly.")
    post_app("heartbeat", {"row": row, "job_id": job_id, "lock": lock, "content_hash": content_hash, "note": "Uploading final AI MP4 to Google Drive."})
    upload = upload_rclone(final_path, youtube_title)
    notes = {
        "mode": PROVIDER_USED,
        "backend": "RunPod cloud GPU + local Wan2.1 T2V scene generation",
        "scenes": len(scenes),
        "duration_seconds": duration,
        "final_path": str(final_path),
        "rclone_remote_path": upload.get("remote_path"),
        "provider": PROVIDER_USED,
    }
    complete_response = post_app("complete", {
        "row": row, "job_id": job_id, "lock": lock, "content_hash": content_hash,
        "output_title": youtube_title,
        "output_file_id": upload.get("file_id", ""),
        "output_file_url": upload.get("url", ""),
        "provider_used": PROVIDER_USED,
        "transcript": transcript,
        "time_marks": time_marks,
        "hashtags": hashtags,
        "keyword_tags": keywords,
        "render_notes": json.dumps(notes, indent=2),
    })
    auto_upload = env("KNR_AUTO_UPLOAD_TO_YOUTUBE_AFTER_RENDER", "false").lower() in ("1", "true", "yes")
    cfg_auto_upload = bool((complete_response.get("config") or {}).get("auto_upload_to_youtube_after_render", False))
    if auto_upload and cfg_auto_upload:
        try:
            post_app("upload_ready", {"limit": 1})
        except Exception as e:
            log("YouTube upload trigger failed after render; Drive output remains ready: " + str(e))
    state["completed_final"] = True
    state["completed_final_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    state["final_path"] = str(final_path)
    save_render_state(state_path, state)
    if env("KNR_DELETE_WORKDIR_AFTER_UPLOAD", "false").lower() in ("1", "true", "yes"):
        shutil.rmtree(workdir, ignore_errors=True)
    log(f"Completed row {row}: {upload.get('url') or upload.get('remote_path')}")


def run_loop(max_jobs=0):
    ensure_apps_script_requirements()
    ensure_runpod_requirements()
    done = 0
    autopaused = False
    no_job = False
    last_row = None
    started_at = time.strftime("%Y-%m-%d %H:%M:%S")
    while True:
        claim = post_app("claim_next")
        if not claim.get("has_job"):
            no_job = True
            log("No READY/QUEUED source or durable job rows. Renderer pass finished.")
            break
        row = claim.get("row")
        last_row = row
        try:
            result = render_job(claim)
            if result == "AUTOPAUSED":
                autopaused = True
                log(f"Row {row} autopaused cleanly. The service will resume after the configured delay from completed scene checkpoints.")
                break
            done += 1
        except Exception as e:
            log(f"ERROR row {row}: {e}")
            try:
                post_app("error", {"row": row, "job_id": claim.get("job_id"), "lock": claim.get("lock"), "content_hash": claim.get("content_hash"), "provider_used": PROVIDER_USED, "error": str(e)})
            except Exception as report_err:
                log(f"Failed to report error to Apps Script: {report_err}")
            if env("KNR_STOP_ON_ERROR", "true").lower() in ("1", "true", "yes"):
                raise
        if max_jobs and done >= max_jobs:
            break
    status = {
        "ok": True,
        "started_at": started_at,
        "finished_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "jobs_done": done,
        "autopaused": autopaused,
        "no_job": no_job,
        "last_row": last_row,
        "max_jobs": int(max_jobs or 0),
        "provider_used": PROVIDER_USED,
    }
    write_renderer_status(status)
    return status


def main():
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--env", default=".env")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--max-jobs", type=int, default=0)
    args = parser.parse_args()
    load_env(Path(args.env))
    if args.once and not args.max_jobs:
        args.max_jobs = 1
    log(APP_NAME + " " + APP_VERSION)
    log("Provider mode: RunPod cloud GPU + local Wan2.1 scene renderer")
    try:
        status = run_loop(args.max_jobs)
        log("Done. Jobs processed: %s autopaused=%s no_job=%s" % (status.get("jobs_done"), status.get("autopaused"), status.get("no_job")))
    except Exception as e:
        write_renderer_status({
            "ok": False,
            "error": str(e)[:2000],
            "jobs_done": 0,
            "autopaused": False,
            "no_job": False,
            "provider_used": PROVIDER_USED,
            "finished_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        raise


if __name__ == "__main__":
    main()
