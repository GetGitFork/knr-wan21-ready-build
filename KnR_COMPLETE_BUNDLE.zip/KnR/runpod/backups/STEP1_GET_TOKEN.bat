@echo off
cd /d "%~dp0"
echo.
echo ============================================================
echo  KnR - Get Google Drive Token (run this if rclone fails)
echo ============================================================
echo.
echo Your browser will open. Sign in with your Google account
echo and click ALLOW when asked about Google Drive access.
echo After you allow, come back here.
echo.
echo Press any key to open browser...
pause > nul
echo.
rclone.exe authorize "drive" --client-id "1006906861486-3dida2av73b2qj2snf0404a4kelpih7i.apps.googleusercontent.com" --client-secret "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"
echo.
echo ============================================================
echo  IMPORTANT: Copy the text that starts with {"access_token":
echo  and ends with }
echo  Then run STEP2_CREATE_CONF.bat and paste it when asked.
echo ============================================================
pause
