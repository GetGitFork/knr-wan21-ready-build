@echo off
cd /d "%~dp0"
echo.
echo ============================================================
echo  KnR - Create rclone.conf from your token
echo ============================================================
echo.
echo Paste the JSON token from STEP1_GET_TOKEN.bat and press Enter:
echo (It starts with {"access_token": and ends with })
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$t=Read-Host 'Paste token here'; ^
$c='[gdrive]'+[char]10+'type = drive'+[char]10+'client_id = 1006906861486-3dida2av73b2qj2snf0404a4kelpih7i.apps.googleusercontent.com'+[char]10+'client_secret = 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'+[char]10+'scope = drive'+[char]10+'token = '+$t+[char]10+'root_folder_id = 1WWjSb2gMpyL6lXxZsbNWPdEekqRgnhAj'; ^
[System.IO.File]::WriteAllText($PWD.Path+'\rclone.conf',$c); ^
Write-Host ''; ^
Write-Host 'rclone.conf created! Now upload your KnR folder to RunPod.'"
echo.
pause
